<?php
session_start();

if (isset($_POST['reiniciar'])) {
    $_SESSION['contadorVisitas'] = 0;
}

if (!isset($_SESSION['contadorVisitas'])) {
    $_SESSION['contadorVisitas'] = 0;
}

$_SESSION['contadorVisitas']++;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>3. Contador en sesión</title>
</head>
<body>
    <h1>3. Contador de visitas</h1>
    <p>Has entrado en esta página <?php echo $_SESSION['contadorVisitas']; ?> veces.</p>
    <p>Cada petición a esta página incrementa el contador.</p>

    <p><a href="contador.php">Hacer una nueva visita sin enviar el formulario</a></p>

    <form method="post">
        <button type="submit" name="reiniciar" value="1">Reiniciar contador</button>
    </form>

    <p>Al reiniciar se muestra 1, porque esta petición cuenta como una nueva visita.</p>
</body>
</html>
