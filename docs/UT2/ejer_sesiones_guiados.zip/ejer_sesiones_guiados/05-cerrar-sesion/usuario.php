<?php
session_start();

$nombre = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre'] ?? '');

    if ($nombre === '') {
        $error = 'Debes indicar un nombre.';
    } else {
        $_SESSION['usuario'] = $nombre;
    }
}

$usuario = $_SESSION['usuario'] ?? 'invitado';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>5. Guardar y borrar una sesión</title>
</head>
<body>
    <h1>5. Guardar y borrar una sesión</h1>
    <p>Usuario: <?php echo htmlspecialchars($usuario); ?></p>
    <p>Este ejercicio guarda un nombre; no es un sistema de autenticación.</p>

    <?php
    if ($error !== '') {
        echo '<p>' . $error . '</p>';
    }
    ?>

    <form method="post">
        <label>
            Nombre:
            <input type="text" name="nombre" maxlength="40" value="<?php echo htmlspecialchars($nombre); ?>">
        </label>
        <button type="submit">Guardar nombre</button>
    </form>

    <p><a href="usuario.php">Volver sin enviar el formulario</a></p>

    <form action="cerrar.php" method="post">
        <button type="submit" name="cerrar" value="1">Vaciar y destruir la sesión</button>
    </form>

    <p>Al cerrar se borran también los datos guardados en los demás ejercicios de esta sesión.</p>
</body>
</html>
