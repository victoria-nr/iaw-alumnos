<?php
session_start();

if (isset($_POST['cerrar'])) {
    $_SESSION = [];
    session_destroy();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>5. Cerrar la sesión</title>
</head>
<body>
    <h1>5. Cerrar la sesión</h1>

    <?php
    if (isset($_POST['cerrar'])) {
        echo '<p>Se han vaciado los datos y se ha destruido la sesión del servidor.</p>';
    } else {
        echo '<p>Usa el botón del formulario para cerrar la sesión.</p>';
    }
    ?>

    <p><a href="usuario.php">Volver y comprobar que aparece invitado</a></p>
    <p><a href="../02-con-sesion/formulario.php">Comprobar que el texto también se ha borrado</a></p>
    <p><a href="../03-contador/contador.php">Comprobar que el contador vuelve a empezar</a></p>
</body>
</html>
