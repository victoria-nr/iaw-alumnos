<?php
session_start();

$palabra = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $palabra = trim($_POST['palabra'] ?? '');

    if ($palabra === '') {
        $error = 'Debes escribir una palabra.';
    } elseif (!ctype_upper($palabra)) {
        $error = 'Debes escribir la palabra en mayúsculas, con letras de A a Z.';
    } else {
        $_SESSION['ultimaPalabra'] = $palabra;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>4. Validación y sesión</title>
</head>
<body>
    <h1>4. Conservar la última palabra válida</h1>

    <?php
    if ($error !== '') {
        echo '<p>' . $error . '</p>';
    }

    if (isset($_SESSION['ultimaPalabra'])) {
        echo '<p>Última palabra válida guardada: ' . htmlspecialchars($_SESSION['ultimaPalabra']) . '</p>';
    } else {
        echo '<p>Todavía no hay una palabra válida guardada.</p>';
    }
    ?>

    <form method="post">
        <label>
            Escribe una palabra en mayúsculas, sin tildes ni ñ:
            <input type="text" name="palabra" maxlength="20" value="<?php echo htmlspecialchars($palabra); ?>">
        </label>
        <button type="submit">Comprobar y guardar</button>
    </form>

    <p><a href="palabra.php">Volver sin enviar el formulario</a></p>
</body>
</html>
