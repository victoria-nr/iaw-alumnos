<?php
$texto = '';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>1. Sin sesión</title>
</head>
<body>
    <h1>1. Una variable normal</h1>
    <p>Texto disponible en esta página: <?php echo htmlspecialchars($texto); ?></p>
    <p>Esta página empieza asignando una cadena vacía a $texto.</p>

    <form action="procesar.php" method="post">
        <label>
            Escribe un texto:
            <input type="text" name="texto" maxlength="40">
        </label>
        <button type="submit">Enviar</button>
    </form>
</body>
</html>
