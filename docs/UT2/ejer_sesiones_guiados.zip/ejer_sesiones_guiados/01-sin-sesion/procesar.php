<?php
$texto = trim($_POST['texto'] ?? '');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>1. Texto recibido</title>
</head>
<body>
    <h1>1. Texto recibido por POST</h1>

    <?php
    if ($texto === '') {
        echo '<p>No se ha recibido ningún texto.</p>';
    } else {
        echo '<p>Texto recibido: ' . htmlspecialchars($texto) . '</p>';
    }
    ?>

    <p>El texto está disponible en esta petición porque el formulario lo ha enviado.</p>
    <p><a href="formulario.php">Volver sin enviar el texto</a></p>
    <p><a href="procesar.php">Abrir de nuevo esta página sin enviar el formulario</a></p>
</body>
</html>
