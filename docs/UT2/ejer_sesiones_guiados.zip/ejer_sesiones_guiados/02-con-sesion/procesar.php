<?php
session_start();

$texto = trim($_POST['texto'] ?? '');
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($texto === '') {
        $error = 'No has escrito ningún texto. El texto anterior se conserva.';
    } else {
        $_SESSION['textoSesion'] = $texto;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>2. Guardar el texto</title>
</head>
<body>
    <h1>2. Guardar el texto</h1>

    <?php
    if ($error !== '') {
        echo '<p>' . $error . '</p>';
    } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
        echo '<p>Texto recibido por POST y guardado en sesión: ' . htmlspecialchars($texto) . '</p>';
    } else {
        echo '<p>Esta petición no ha recibido un formulario por POST.</p>';
    }

    if (isset($_SESSION['textoSesion'])) {
        echo '<p>Texto disponible en sesión: ' . htmlspecialchars($_SESSION['textoSesion']) . '</p>';
    }
    ?>

    <p><a href="formulario.php">Volver al formulario sin enviar el texto</a></p>
    <p><a href="procesar.php">Abrir de nuevo esta página sin enviar el formulario</a></p>
</body>
</html>
