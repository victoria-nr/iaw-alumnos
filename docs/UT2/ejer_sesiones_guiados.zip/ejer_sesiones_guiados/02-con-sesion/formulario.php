<?php
session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>2. Con sesión</title>
</head>
<body>
    <h1>2. Conservar un texto en sesión</h1>

    <?php
    if (isset($_SESSION['textoSesion'])) {
        echo '<p>Texto guardado: ' . htmlspecialchars($_SESSION['textoSesion']) . '</p>';
    } else {
        echo '<p>Todavía no hay un texto guardado.</p>';
    }
    ?>

    <form action="procesar.php" method="post">
        <label>
            Escribe un texto:
            <input type="text" name="texto" maxlength="40">
        </label>
        <button type="submit">Guardar en sesión</button>
    </form>

    <p><a href="formulario.php">Volver a abrir esta página sin enviar el formulario</a></p>
</body>
</html>
